from demoji.main import main

main()
